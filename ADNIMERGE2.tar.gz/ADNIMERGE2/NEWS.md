# NOTE 

* Since `ADNIMERGE2` is an R data package, and the data in the package will be often updated, only major change logs related to an R function in the `ADNIMERGE2` package will be listed in the version history.

# ADNIMERGE2 0.1.1

* Initial data package.
