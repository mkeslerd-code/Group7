#' @keywords internal
"_PACKAGE"

## usethis namespace: start
#' @importFrom rmarkdown pdf_document knitr_options_pdf
#' @importFrom bookdown pdf_document2 html_document2 html_vignette2
## usethis namespace: end
NULL

globalVariables(c("."))
