library(testthat)
library(ADNIMERGE2)

test_check("ADNIMERGE2")
